# BetGuard AI

A small, explainable risk-scoring engine for flagging account-level fraud
patterns in online betting/gaming accounts — multi-accounting, bonus abuse,
and irregular deposit activity — built as a learning project and portfolio
piece.

> **This is a demo built on invented, fictional data.** It is not connected
> to Betway, any real betting company, real accounts, real payments, or
> real betting activity of any kind.

## What it does

Every account is scored against three signals:

| Signal                    | What it flags                                              |
|----------------------------|-------------------------------------------------------------|
| Shared device accounts     | Multiple accounts logging in from the same device           |
| Bonus claims                | How many promo/free-bet offers an account has claimed        |
| Deposit pattern             | Whether recent deposits break from the account's own history |

Those combine into a single 0–100 risk score, which maps to a tier:

| Score  | Tier      | Action                                              |
|--------|-----------|------------------------------------------------------|
| 0–29   | Low       | No action — continue normal monitoring               |
| 30–59  | Moderate  | Flag for a closer look at the next natural touchpoint |
| 60–100 | High      | Hold for manual review before approving bonuses/payouts |

## Project structure

```
betguard-ai/
├── cli/
│   └── betguard_risk_calculator.py   # Interactive command-line version
├── web-demo/
│   └── index.html                    # Live slider + gauge demo (open in any browser)
└── docs/
    └── ARCHITECTURE.md               # Proposed production architecture (design, not built)
```

## Running it

**CLI version** — no dependencies beyond Python 3:

```bash
python3 cli/betguard_risk_calculator.py
```

**Web demo** — no build step, just open the file:

```bash
open web-demo/index.html   # macOS
# or just double-click it / drag into a browser
```

## Why rule-based, not ML

The scoring model uses transparent, adjustable weights rather than a
black-box model. That's a deliberate choice at this stage — it's easy to
explain to a non-technical reviewer, easy to tune by hand, and doesn't
require training data that doesn't exist yet. See
[`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) for how this could evolve
toward a trained model given real, labeled data.

## Status

Working MVP and demo. Not production software, not benchmarked, not
integrated with any real system. Built by [Oganne Baitsile](https://github.com/)
as a self-directed project.

## License

MIT — see [LICENSE](LICENSE).
