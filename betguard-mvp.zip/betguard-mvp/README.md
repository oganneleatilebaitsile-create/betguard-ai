# BetGuard AI — Review Console (MVP)

A browser-based review console for the BetGuard AI risk-scoring concept —
a dashboard, review queue, and case-detail view for triaging flagged
accounts.

> **Fictional data only.** Every case, account, and note on this page is
> invented for demonstration. Not connected to Betway, any real betting
> company, real accounts, payments, or real betting activity.

## Running it

No build step, no server, no dependencies. Just open the file:

```bash
open index.html   # macOS — or double-click it, or drag into any browser
```

## What's included

- **Dashboard statistics** — total cases and a breakdown by risk tier.
- **Review queue** — every fictional case, sorted by score, with search
  (by account ID or name) and filters (by risk tier and by status).
- **Case detail panel** — click any case to see its signal breakdown
  (shared-device accounts, bonus claims, deposit pattern), change its
  status, and add reviewer notes.
- **Reviewer notes and status** persist in the browser's local storage,
  so they survive a page refresh (but are local to your browser only —
  there's no backend or shared database here).
- **Mobile-friendly** — the queue collapses to stacked rows and the detail
  panel goes full-screen below ~720px width.

## Files

```
index.html   Page structure
style.css    Styling (dark theme, responsive)
app.js       Fictional case data + all interactivity
README.md    This file
```

## Scoring model

Each case's score comes from the same simple, transparent formula used
throughout this project:

```
score = min(100, device_count × 6 + bonus_claims × 2 + deposit_points)
deposit_points: None=0, Mild=10, Moderate=20, Severe=30
```

Tiers: **Low** (0–29), **Moderate** (30–59), **High** (60–100).

## Status

Working demo, not production software. See the wider project's
`docs/ARCHITECTURE.md` for how this could evolve toward a production
system with real data.
